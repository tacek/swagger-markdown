# [1.2.0](https://github.com/syroegkin/swagger-markdown/compare/v1.1.7...v1.2.0) (2019-06-24)


### Features

* resolve multiple properties with allOf ([9fae4dc](https://github.com/syroegkin/swagger-markdown/commit/9fae4dc))

## [1.0.1](https://github.com/syroegkin/swagger-markdown/compare/v1.0.0...v1.0.1) (2019-06-01)


### Bug Fixes

* force release (hack) ([ae48f63](https://github.com/syroegkin/swagger-markdown/commit/ae48f63))

# 1.1.6 (2019-06-01)


### Bug Fixes

* package.json to reduce vulnerabilities ([422e0f0](https://github.com/syroegkin/swagger-markdown/commit/422e0f0))
* security types should handle objects ([9189823](https://github.com/syroegkin/swagger-markdown/commit/9189823))
* **definitions:** avoid undefined ([714c912](https://github.com/syroegkin/swagger-markdown/commit/714c912))
* **definitions:** Replace newlines with spaces in table ([ad72a3b](https://github.com/syroegkin/swagger-markdown/commit/ad72a3b))
* **package:** change gitlab plugin to github ([d8e6b49](https://github.com/syroegkin/swagger-markdown/commit/d8e6b49))
